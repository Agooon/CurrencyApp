﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CurrencyApp.Pages.Account
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}

