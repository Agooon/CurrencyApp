﻿namespace CurrencyApp.Models
{
    public class RateModel
    {
        public string Currency { get; set; }
        public string Code { get; set; }
        public float Mid { get; set; }
    }

}
