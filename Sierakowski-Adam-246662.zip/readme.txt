Podaje jeszcze link do github'a, gdyby chciał Pan w przyszłości zobaczyć jak (mam nadzieję że bardzo) aplikacja się rozrosła :)

https://github.com/Agooon/CurrencyApp